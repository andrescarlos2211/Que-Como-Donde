Falta
>responsividad
>imagen aleatoria
>implementar barra de busqueda
>implementar responsividad
